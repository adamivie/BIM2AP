# Bosch Mode 2 Automation

A library for interacting with Bosch Intrusion Mode 2 panels.

## Installation

You can install the library using pip:

```bash
pip install bosch_mode2_automation
```
